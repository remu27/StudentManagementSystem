#ifndef GRADE_H
#define GRADE_H

#include "student.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ���� ���� �Լ���
int add_grade(StudentRecord *record, const char *subject, 
              float score, int credit);
int update_grade(StudentRecord *record, const char *subject, float new_score);
int delete_grade(StudentRecord *record, const char *subject);
Grade* search_grade(StudentRecord *record, const char *subject);

// ���� ��� �Լ���
float calculate_gpa(StudentRecord *record);
char score_to_grade(float score);
float calculate_average_score(const StudentRecord *record);
float calculate_total_credits(const StudentRecord *record);

// ���� ��� �Լ���
void display_transcript(const StudentRecord *record);
void display_grade_summary(const StudentRecord *record);

// ��ƿ��Ƽ �Լ���
int is_valid_score(float score);
int is_valid_credit(int credit);
int has_subject(const StudentRecord *record, const char *subject);

#endif // GRADE_H
